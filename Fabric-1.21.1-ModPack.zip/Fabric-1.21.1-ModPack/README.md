# Fabric 1.21.1 Mod Paketi

Minecraft: **1.21.1**  
Mod yükleyici: **Fabric**  
ZIP içerisinde `mods/` klasörü, bu README ve `RAPOR.md` bulunur. Fabric Loader JAR’ı pakete eklenmemiştir.

## Modlar ve kütüphaneler

### ImmediatelyFast
- Sürüm: `1.6.15+1.21.1`
- JAR: `mods/ImmediatelyFast-Fabric-1.6.15+1.21.1.jar`
- Proje: https://modrinth.com/mod/immediatelyfast
- Zorunlu bağımlılıklar: Java 21+, Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz)
- SHA-512: `d4ac2d574d80000cd59b0b362706a6f86778bfc717748dca854f05ee8d09ce158738488e58c6b8ee05d5e54017f05b6c66c3bcaa3fa357d38cbfd75893dda9f4` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Mouse Tweaks
- Sürüm: `2.26`
- JAR: `mods/MouseTweaks-fabric-mc1.21-2.26.jar`
- Proje: https://modrinth.com/mod/mouse-tweaks
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Fabric API, Java 21+
- İsteğe bağlı bağımlılıklar/uyumluluklar: Mod Menu (isteğe bağlı)
- SHA-512: `1744a48a47aedcbf19a0a93f78473cf0221fc4782852dca7fc02685719174664b4f9d95d353fcfc16902ac3815594511ba6d9ab14391f9b7e25ec9b2e777927a` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### AppleSkin
- Sürüm: `3.0.6+mc1.21`
- JAR: `mods/appleskin-fabric-mc1.21-3.0.6.jar`
- Proje: https://modrinth.com/mod/appleskin
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Fabric API
- İsteğe bağlı bağımlılıklar/uyumluluklar: Mod Menu (isteğe bağlı)
- SHA-512: `accbb36b863bdeaaeb001f7552534f3bdf0f27556795cf8e813f9b32e7732450ec5133da5e0ec9b92dc22588c48ffb61577c375f596dc351f15c15ce6a6f4228` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Auto Sprint
- Sürüm: `1.0.1`
- JAR: `mods/auto-sprint-1.0.1+1.21.1.jar`
- Proje: https://modrinth.com/mod/auto-sprint-plus
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Java 21+, Fabric API
- Seçim notu: İstenen Auto Sprint projesinin 1.21.1/Fabric dosyası yok; bu ayrı proje en yakın uyumlu alternatiftir.
- SHA-512: `9a95025192c4ccab510eb272a5e69cc0e26c596514913a79604c455cf70ebbb86d8297381c0332c42a1d9510a2a9f4fdba71a5cb3c4bc07f4569111cf45d8665` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### CIT Resewn
- Sürüm: `1.2.2+1.21`
- JAR: `mods/citresewn-1.2.2+1.21.jar`
- Proje: https://modrinth.com/mod/cit-resewn
- Zorunlu bağımlılıklar: Fabric API, Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz)
- Seçim notu: 1.21.1/Fabric için kararlı sürüm bulunmadı; beta sürüm kullanılıyor.
- SHA-512: `24338b35423798b3d842025d2a8725b980980b7ccb168b876e21ea1d4067ecba3f67918b0d6b8b332128841ab6cbe2c2d3fd408c0dd36eeeb36cb76a875c442a` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Cloth Config v15
- Sürüm: `15.0.140`
- JAR: `mods/cloth-config-15.0.140-fabric.jar`
- Proje: https://modrinth.com/mod/cloth-config
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz)
- SHA-512: `1b3f5db4fc1d481704053db9837d530919374bf7518d7cede607360f0348c04fc6347a3a72ccfef355559e1f4aef0b650cd58e5ee79c73b12ff0fc2746797a00` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Crosshair Indicator
- Sürüm: `1.21`
- JAR: `mods/crosshair-indicator-1.21.jar`
- Proje: https://modrinth.com/mod/crosshair-indicator
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Java 21+, Fabric API
- Seçim notu: Modrinth sürümü `1.21` adıyla yayımlanmış; uyumluluk metadata’sı 1.21.1’i açıkça içeriyor.
- SHA-512: `4945df45e5779976294986814d902aad007f5ba1bd6da935357c24e45939cded61f39382706d5a15535712b414887066372570ec77018ac96c26d129b435eb19` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Dynamic FPS
- Sürüm: `3.11.4`
- JAR: `mods/dynamic-fps-3.11.4+minecraft-1.21.0-fabric.jar`
- Proje: https://modrinth.com/mod/dynamic-fps
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Fabric Loader ile gelen MixinExtras (dışarıdan ayrıca JAR gerektirmez), Fabric API
- İsteğe bağlı bağımlılıklar/uyumluluklar: Mod Menu (isteğe bağlı), Cloth Config API (isteğe bağlı)
- SHA-512: `42c7043517889274f2932f257a78d0a67c22f2bebb1385ab4d0ba7936da2163e907d63f22bfeed5126342b568ddf4d7bc576ab6e76401a07d20a4978ba61bf20` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### EntityCulling
- Sürüm: `1.11.3`
- JAR: `mods/entityculling-fabric-1.11.3-mc1.21.1.jar`
- Proje: https://modrinth.com/mod/entityculling
- Zorunlu bağımlılıklar: Fabric API
- SHA-512: `51cc760b886f53a8469f5f87098688c8e00a70e9499f4146908f676dc95c78bbfd6de6ddab124e5ba8c1057335c3727c24243af2807497c6e4b05cb2da811364` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Fabric API
- Sürüm: `0.116.17+1.21.1`
- JAR: `mods/fabric-api-0.116.17+1.21.1.jar`
- Proje: https://modrinth.com/mod/fabric-api
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Java 21+
- SHA-512: `98c478217da19181f0e4df3ea6c2da6bdbda271c7544a4aea048513a49b444f1ff5b71dc0df6303017c48e8ff69b7bb6af6179bdf0d0e09ab3c1ee08411857a8` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Fabric Language Kotlin
- Sürüm: `1.14.2+kotlin.2.4.21`
- JAR: `mods/fabric-language-kotlin-1.14.2+kotlin.2.4.21.jar`
- Proje: https://modrinth.com/mod/fabric-language-kotlin
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz)
- SHA-512: `7fb475c4a7e7bdf8d0aca4b5798a58a354c51443d5b1fbde3e8cf34dfbf7191ef4238b5f07d08ec9490ec180b371624523326c3ad45d4ed2b2be541de9407e5d` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### FerriteCore
- Sürüm: `7.0.3`
- JAR: `mods/ferritecore-7.0.3-fabric.jar`
- Proje: https://modrinth.com/mod/ferrite-core
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz)
- SHA-512: `3ad31620fac4ff44327dc7dedbe162b2d978f3f246dc16255a6e400ce9592a0d326fe36a626f3c1bf30a11f813093cbb4dcc107af039cff724d0cdf648541fdf` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### FreeLook
- Sürüm: `1.6.0`
- JAR: `mods/freelook-fabric-1.21-1.6.0.jar`
- Proje: https://modrinth.com/mod/freelook-og
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Java 21+
- SHA-512: `e71e4b7758bfd47230579200e7172cc236aef7753248ccdcffd5ec04e5957326a543e7cccdcf7e7494a13867a5d8fb819cdc1e08f19ec697198bdd32d22c4ac7` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Inventory HUD +
- Sürüm: `3.4.26`
- JAR: `mods/inventoryhud.fabric.1.21.1-3.4.26.jar`
- Proje: https://www.curseforge.com/minecraft/mc-mods/inventory-hud-forge
- Dosya sayfası: https://www.curseforge.com/minecraft/mc-mods/inventory-hud-forge/files/5639986
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Fabric API, Java 21+
- SHA-512: `d6cf249ba96d57ba86a2798c955ef8321cde43c11028cd6b5b18b8e7877f55f710ddc01db9d54254d97fbbe0536c8e045e21167f5d04d1fe199a0fc547a09eb9` (indirilen CurseForge dosyasından hesaplandı; sayfada resmî hash yayımlanmıyor)

### Lithium
- Sürüm: `0.15.4+mc1.21.1`
- JAR: `mods/lithium-fabric-0.15.4+mc1.21.1.jar`
- Proje: https://modrinth.com/mod/lithium
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz)
- SHA-512: `182064b00e6315e2255b857eaab8eb759e6b042ebd4cc8b855ff0d93f875a5a7188fac49f878d7b29d4ef7e6b6341190ad7f6f6f39f4a6d2c62003468b08e4c6` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Mod Menu
- Sürüm: `11.0.5`
- JAR: `mods/modmenu-11.0.5.jar`
- Proje: https://modrinth.com/mod/modmenu
- Zorunlu bağımlılıklar: Fabric API, Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Text Placeholder API (Modrinth metadata)
- SHA-512: `92e8e96267ff18d320903090f2ad9b32408a218919f5a0d578e232ad774c89d49a34a8271806652be7d6283f24e98432bc4af7f95855e78b843f9100d68696c7` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### NotEnoughAnimations
- Sürüm: `1.12.6`
- JAR: `mods/notenoughanimations-fabric-1.12.6-mc1.21.1.jar`
- Proje: https://modrinth.com/mod/not-enough-animations
- Zorunlu bağımlılıklar: Fabric API
- SHA-512: `0e7da5238701c159f9a8e4f55ad48533a2228ff1b9f598ab420be737dfd25b840f950ad56cdf6be54177b92466063fdc6a9c86e4ab3bbcae5f22299e008dea85` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Placeholder API
- Sürüm: `2.4.2+1.21`
- JAR: `mods/placeholder-api-2.4.2+1.21.jar`
- Proje: https://modrinth.com/mod/placeholder-api
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz)
- SHA-512: `fc13d3a5c048dbaab86318edaf8b6c6b46ef9f1d367e8f063d19f5a9b0da66c5ae419d92c8c4608edc89a01eb44d91ffcf017fea73f39b222cbd85e82f70a233` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Sodium Extra
- Sürüm: `0.9.5+mc1.21.1`
- JAR: `mods/sodium-extra-fabric-0.9.5+mc1.21.1.jar`
- Proje: https://modrinth.com/mod/sodium-extra
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Sodium
- İsteğe bağlı bağımlılıklar/uyumluluklar: Reese’s Sodium Options, Sodium Shadowy Path Blocks vb. (isteğe bağlı; pakete dahil değil)
- SHA-512: `2587475562472b7e5cdc8c2b4409de498815402156524242acbad9672a0c348288b9b3328ec82b9300593d1a02eb71022704742889e5b33b755f75709cf16827` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Sodium
- Sürüm: `0.8.13+mc1.21.1`
- JAR: `mods/sodium-fabric-0.8.13+mc1.21.1.jar`
- Proje: https://modrinth.com/mod/sodium
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Fabric API
- SHA-512: `8614a374593698069a80ac74de8cd9c28f3928d16819a0e0d6320b538e823f7e54e8be06d5ea5a9c268beb0e02073209d1f831a02dede851588b972367680853` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Status Effect Bars
- Sürüm: `1.0.6`
- JAR: `mods/status-effect-bars-1.0.6.jar`
- Proje: 
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Cloth Config API
- İsteğe bağlı bağımlılıklar/uyumluluklar: Mod Menu (isteğe bağlı, Modrinth sürüm metadata’sı)
- SHA-512: `3e33772836b72d05a169c853a87971f56ca202604486d50fc408b604eef697acc66274491d0ad85544ca2446af7d9172955a9b28b626c543118125fa812f9652` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### YetAnotherConfigLib
- Sürüm: `3.8.2+1.21.1-fabric`
- JAR: `mods/yet_another_config_lib_v3-3.8.2+1.21.1-fabric.jar`
- Proje: https://modrinth.com/mod/yacl
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Java 21+, Fabric API
- SHA-512: `353169f85fa63e73ce9bdd0d4ddce54e3cbc4d71153a93c982f74c68fd93325986663f94fc2f2b10f4427e8b15a0485c608c5587b3840d933204b50ea4cb6d4c` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

### Zoomify
- Sürüm: `2.15.2+1.21.1`
- JAR: `mods/zoomify-2.15.2+1.21.1.jar`
- Proje: https://modrinth.com/mod/zoomify
- Zorunlu bağımlılıklar: Fabric Loader (dışarıdan kurulur; `mods/` içine konmaz), Fabric Language Kotlin, Java 21+, YetAnotherConfigLib (YACL)
- SHA-512: `ce8db36e77f089f091986b6e8bea1c33433bbcffc7a47fa18d04dea5ecd4910286943600a85b4773fdf4ed5405f52f3c0dc08fea8b1551d7725a26e1f6ef2879` (Modrinth API dosya SHA-512 değeriyle doğrulandı)

## Çalıştırma koşulları

- Minecraft 1.21.1 ve Java 21 gerekir.
- Paket Fabric Loader kurulumunu içermez; Sodium Extra için gereken asgari Fabric Loader sürümü `0.20.1` olmalıdır. Fabric Loader ile gelen MixinExtras, Dynamic FPS bağımlılığını karşılar.
- Mod metadata’sındaki oyun sürümü ve zorunlu bağımlılık aralıkları karşılaştırıldı; açık bir sürüm uyuşmazlığı görülmedi. Sodium Extra, tam olarak eklenen Sodium `0.8.13+mc1.21.1` sürümünü ister.

## Hash kontrolü

Modrinth kaynaklı JAR’ların SHA-512 değerleri indirme sırasında resmî Modrinth API’sindeki SHA-512 ile eşleştirildi. Inventory HUD+ için hash yerel olarak hesaplandı.
