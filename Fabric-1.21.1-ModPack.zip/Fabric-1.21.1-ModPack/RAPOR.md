# Uyumluluk ve indirme raporu

- Hedef Minecraft 1.21.1 ve Fabric’dir. JAR içindeki `fabric.mod.json` sürüm/dependency alanları incelendi; açık bir sürüm çakışması görülmedi.
- **Auto Sprint:** İstenen Modrinth `auto-sprint-chadhik` projesinde 1.21.1/Fabric sürümü yok. Aynı isimli proje gibi göstermemek için işlevsel en yakın, ayrı proje olan `Auto Sprint Plus 1.0.1` eklendi: https://modrinth.com/mod/auto-sprint-plus
- **CIT Resewn:** 1.21.1/Fabric için kararlı sürüm bulunmadı; uyumlu en güncel beta `1.2.2+1.21` eklendi.
- **Crosshair Indicator:** `crosshair-indicator` projesi seçildi. Sürüm etiketi `1.21`, ancak proje metadata’sı 1.21.1 desteğini listeliyor. Bu, hedef oyuncu hitboxına vurulabilir olduğunda nişangâhı değiştiren moddur. Benzer adlı `crosshairindicator` projesinde 1.21.1/Fabric dosyası yok.
- **Freelook:** 1.21.1/Fabric sürümü bulunan `freelook-og` (The Original FreeLook Mod) seçildi.
- **Inventory HUD+:** Orijinal dmitrylovin CurseForge projesinden, sayfasında Fabric + Minecraft 1.21.1 olarak işaretlenen 3.4.26 dosyası kullanıldı.
- Zorunlu bağımlılıklar eklendi ve tekilleştirildi: Fabric API, Fabric Language Kotlin, YACL, Text Placeholder API ve Cloth Config API. Sodium Extra’nın gerektirdiği tam Sodium sürümü pakette.
- Fabric Loader JAR olarak eklenmedi. Başlatıcıda Minecraft 1.21.1, Fabric Loader 0.20.1 veya üstü ve Java 21 seçilmelidir. Dynamic FPS’in MixinExtras gereksinimi Fabric Loader çalışma zamanında sağlanır.
- Modrinth dosyalarının SHA-512 değerleri indirme sırasında resmî Modrinth API hashleriyle karşılaştırıldı. CurseForge Inventory HUD+ dosyasının SHA-512 değeri hesaplandı; CurseForge dosya sayfası karşılaştırılabilir hash yayımlamıyor.
